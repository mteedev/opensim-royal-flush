<?php
/**
 * Plugin Name: OpenSimulator Royal Flush
 * Plugin URI:  https://nerdypappy.com/opensim-royal-flush
 * Description: Automatically emails no-avatar WordPress accounts at Day 30 and Day 59, flags them for admin review at Day 60, and provides a safe bulk-deletion review screen. Built for OpenSimulator grids running w4os. The Royal Flush — because every grid deserves a clean database.
 * Version:     1.0.0
 * Author:      Gundahar Bravin
 * Author URI:  https://nerdypappy.com
 * License:     GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: opensim-royal-flush
 *
 * OpenSimulator Royal Flush
 * Copyright (C) 2026 Gundahar Bravin / NeverWorld Grid
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ORF_VERSION',         '1.0.0' );
// orf_get_avatar_url() is generated at runtime via orf_get_avatar_url() to avoid calling home_url() too early
define( 'ORF_MENU_SLUG',       'opensim-royal-flush' );
define( 'ORF_META_D30',        'orf_email_d30' );
define( 'ORF_META_D59',        'orf_email_d59' );
define( 'ORF_META_QUEUED',     'orf_queued' );
define( 'ORF_OPTION_TRUSTED',  'orf_trusted_domains' );
define( 'ORF_DEFAULT_TRUSTED', implode( "\n", array(
    'gmail.com','yahoo.com','yahoo.co.uk','yahoo.fr','yahoo.de',
    'hotmail.com','hotmail.co.uk','outlook.com','live.com','msn.com',
    'proton.me','protonmail.com','protonmail.ch',
    'icloud.com','me.com','mac.com',
    'aol.com','gmx.com','gmx.net','gmx.de','web.de',
    'mail.com','zoho.com','yandex.com','yandex.ru','mail.ru','rambler.ru',
    'inbox.com','fastmail.com','tutanota.com','hey.com',
    'optonline.net','comcast.net','verizon.net','att.net',
    'sbcglobal.net','cox.net','charter.net','earthlink.net',
) ) );

// ---------------------------------------------------------------------------
// AVATAR URL HELPER — home_url() must not be called at define() time
// ---------------------------------------------------------------------------
function orf_get_avatar_url() {
    return home_url( '/my-account/avatar/' );
}

// ---------------------------------------------------------------------------
// ACTIVATION / DEACTIVATION
// ---------------------------------------------------------------------------
register_activation_hook( __FILE__, 'orf_activate' );
register_deactivation_hook( __FILE__, 'orf_deactivate' );

function orf_activate() {
    if ( ! wp_next_scheduled( 'orf_daily_scan' ) )
        wp_schedule_event( time(), 'daily', 'orf_daily_scan' );
    if ( ! get_option( ORF_OPTION_TRUSTED ) )
        update_option( ORF_OPTION_TRUSTED, ORF_DEFAULT_TRUSTED );
}

function orf_deactivate() {
    wp_clear_scheduled_hook( 'orf_daily_scan' );
}

// ---------------------------------------------------------------------------
// TRUSTED DOMAINS
// ---------------------------------------------------------------------------
function orf_get_trusted_domains() {
    $raw = get_option( ORF_OPTION_TRUSTED, ORF_DEFAULT_TRUSTED );
    return array_filter( array_map( function($l){ return strtolower(trim($l)); }, explode("\n",$raw) ) );
}

function orf_is_trusted( $domain ) {
    return in_array( strtolower(trim($domain)), orf_get_trusted_domains() );
}

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------
function orf_user_has_avatar( $user_id ) {
    return ! empty( get_user_meta( $user_id, 'w4os_uuid', true ) );
}

function orf_is_exempt( $user ) {
    if ( is_int($user) ) $user = get_userdata($user);
    if ( ! $user ) return true;
    return user_can( $user, 'edit_posts' );
}

function orf_get_no_avatar_users() {
    $users = get_users( array(
        'meta_query' => array( 'relation' => 'OR',
            array( 'key' => 'w4os_uuid', 'compare' => 'NOT EXISTS' ),
            array( 'key' => 'w4os_uuid', 'value' => '', 'compare' => '=' ),
        ),
        'number' => -1,
    ) );
    return array_filter( $users, function($u){ return ! orf_is_exempt($u); } );
}

function orf_days( $user ) {
    return (int) floor( ( time() - strtotime($user->user_registered) ) / DAY_IN_SECONDS );
}

function orf_domain( $email ) {
    $p = explode('@', $email);
    return isset($p[1]) ? strtolower(trim($p[1])) : 'unknown';
}

// ---------------------------------------------------------------------------
// EMAILS
// ---------------------------------------------------------------------------
function orf_send_email( $user, $type ) {
    $site = get_bloginfo('name');
    $url  = orf_get_avatar_url();
    $name = $user->user_login;

    if ( $type === 'd30' ) {
        $subject = "Don't forget to create your {$site} Avatar!";
        $body  = "Hi {$name},\n\n";
        $body .= "You signed up for {$site} but haven't created your Avatar yet.\n\n";
        $body .= "It's quick and easy — just follow the link below and the on-screen helper will guide you through every step:\n\n";
        $body .= "{$url}\n\n";
        $body .= "Once your Avatar is created you'll be ready to log in and explore the grid!\n\n";
        $body .= "See you in-world!\nThe {$site} Team\n";
    } else {
        $subject = "Action Required — Your {$site} account will be removed tomorrow";
        $body  = "Hi {$name},\n\n";
        $body .= "This is a final notice that your {$site} account is scheduled to be removed tomorrow.\n\n";
        $body .= "You signed up but never created an Avatar, so your account has been inactive since registration.\n\n";
        $body .= "If you'd like to keep your account, create your Avatar right now — it only takes a minute:\n\n";
        $body .= "{$url}\n\n";
        $body .= "Just follow the on-screen helper and you'll be in-world in no time.\n\n";
        $body .= "If you don't create your Avatar, your account will be queued for removal. You're always welcome to sign up again!\n\n";
        $body .= "The {$site} Team\n";
    }

    return wp_mail( $user->user_email, $subject, $body, array('Content-Type: text/plain; charset=UTF-8') );
}

// ---------------------------------------------------------------------------
// DAILY CRON SCAN
// ---------------------------------------------------------------------------
add_action( 'orf_daily_scan', 'orf_run_scan' );

function orf_run_scan() {
    foreach ( orf_get_no_avatar_users() as $user ) {
        if ( orf_user_has_avatar($user->ID) ) continue;
        $days   = orf_days($user);
        $d30    = get_user_meta($user->ID, ORF_META_D30, true);
        $d59    = get_user_meta($user->ID, ORF_META_D59, true);
        $queued = get_user_meta($user->ID, ORF_META_QUEUED, true);

        if ( $days >= 30 && !$d30 && orf_send_email($user,'d30') )
            update_user_meta($user->ID, ORF_META_D30, current_time('mysql'));
        if ( $days >= 59 && !$d59 && orf_send_email($user,'d59') )
            update_user_meta($user->ID, ORF_META_D59, current_time('mysql'));
        if ( $days >= 60 && !$queued )
            update_user_meta($user->ID, ORF_META_QUEUED, current_time('mysql'));
    }
}

// ---------------------------------------------------------------------------
// ADMIN MENU
// ---------------------------------------------------------------------------
add_action( 'admin_menu', 'orf_admin_menu' );

function orf_admin_menu() {
    add_users_page( 'OpenSimulator Royal Flush', '👑 Royal Flush', 'manage_options', ORF_MENU_SLUG, 'orf_admin_page' );
    add_users_page( 'Royal Flush Settings', 'Royal Flush Settings', 'manage_options', 'orf-settings', 'orf_settings_page' );
}

// ---------------------------------------------------------------------------
// ADMIN INIT
// ---------------------------------------------------------------------------
add_action( 'admin_init', 'orf_admin_init' );

function orf_admin_init() {
    if ( ! current_user_can('manage_options') ) return;

    if ( isset($_POST['orf_scan']) && wp_verify_nonce($_POST['orf_scan_nonce'],'orf_manual_scan') ) {
        orf_run_scan();
        orf_set_notice('success','Manual scan complete. Queue updated.');
        wp_safe_redirect(admin_url('users.php?page='.ORF_MENU_SLUG)); exit;
    }

    if ( isset($_POST['orf_save_settings']) && wp_verify_nonce($_POST['orf_settings_nonce'],'orf_settings') ) {
        update_option(ORF_OPTION_TRUSTED, sanitize_textarea_field($_POST['orf_trusted_domains'] ?? ''));
        orf_set_notice('success','Trusted domains saved.');
        wp_safe_redirect(admin_url('users.php?page=orf-settings')); exit;
    }

    if ( isset($_POST['orf_delete']) && wp_verify_nonce($_POST['orf_nonce'],'orf_delete') ) {
        $ids = isset($_POST['orf_users']) ? array_map('intval',$_POST['orf_users']) : array();
        $deleted = 0; $skipped = 0;
        require_once ABSPATH.'wp-admin/includes/user.php';
        foreach ($ids as $uid) {
            if ( orf_is_exempt($uid) || orf_user_has_avatar($uid) || $uid===get_current_user_id() ) { $skipped++; continue; }
            wp_delete_user($uid); $deleted++;
        }
        $msg = $deleted.' account(s) flushed.';
        if ($skipped) $msg .= ' '.$skipped.' skipped (protected).';
        orf_set_notice('success',$msg);
        wp_safe_redirect(admin_url('users.php?page='.ORF_MENU_SLUG)); exit;
    }
}

// ---------------------------------------------------------------------------
// NOTICE HELPERS
// ---------------------------------------------------------------------------
function orf_set_notice($type,$text) { set_transient('orf_notice',$type.'|'.$text,30); }

function orf_show_notice() {
    $n = get_transient('orf_notice');
    if (!$n) return;
    list($type,$text) = explode('|',$n,2);
    echo '<div class="notice '.($type==='success'?'notice-success':'notice-warning').' is-dismissible"><p>'.esc_html($text).'</p></div>';
    delete_transient('orf_notice');
}

// ---------------------------------------------------------------------------
// SETTINGS PAGE
// ---------------------------------------------------------------------------
function orf_settings_page() {
    orf_show_notice();
    $current = get_option(ORF_OPTION_TRUSTED, ORF_DEFAULT_TRUSTED);
    $count   = count(orf_get_trusted_domains());
    ?>
    <div class="wrap">
        <h1>👑 Royal Flush — Trusted Domains</h1>
        <p>Domains listed here are <strong>never</strong> flagged as bot farm domains. Common providers are pre-populated. Add one domain per line, lowercase.</p>
        <p style="color:#666;"><strong><?php echo $count; ?> trusted domains</strong> currently configured.</p>
        <form method="post">
            <?php wp_nonce_field('orf_settings','orf_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="orf_trusted_domains">Trusted Domains</label></th>
                    <td>
                        <textarea name="orf_trusted_domains" id="orf_trusted_domains" rows="25"
                            style="width:380px;font-family:monospace;font-size:13px;"><?php echo esc_textarea($current); ?></textarea>
                        <p class="description">One domain per line. e.g. <code>gmail.com</code></p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <button type="submit" name="orf_save_settings" value="1" class="button button-primary">Save Trusted Domains</button>
                <a href="<?php echo admin_url('users.php?page='.ORF_MENU_SLUG); ?>" class="button" style="margin-left:8px;">← Back to Royal Flush</a>
            </p>
        </form>
        <hr>
        <h3>Reset to Defaults</h3>
        <form method="post">
            <?php wp_nonce_field('orf_settings','orf_settings_nonce'); ?>
            <input type="hidden" name="orf_trusted_domains" value="<?php echo esc_attr(ORF_DEFAULT_TRUSTED); ?>">
            <button type="submit" name="orf_save_settings" value="1" class="button"
                onclick="return confirm('Reset trusted domains to defaults?')">Reset to Defaults</button>
        </form>
    </div>
    <?php
}

// ---------------------------------------------------------------------------
// MAIN ADMIN PAGE
// ---------------------------------------------------------------------------
function orf_admin_page() {
    orf_show_notice();

    $all_users = orf_get_no_avatar_users();
    usort($all_users, function($a,$b){ return strtotime($a->user_registered)-strtotime($b->user_registered); });

    $domain_counts = array();
    foreach ($all_users as $u) {
        $d = orf_domain($u->user_email);
        $domain_counts[$d] = ($domain_counts[$d] ?? 0)+1;
    }
    arsort($domain_counts);

    $bot_domains = array_filter($domain_counts, function($c,$d){
        return $c>1 && !orf_is_trusted($d);
    }, ARRAY_FILTER_USE_BOTH);

    $total         = count($all_users);
    $queued        = count(array_filter($all_users,function($u){return !empty(get_user_meta($u->ID,ORF_META_QUEUED,true));}));
    $disabled      = count(array_filter($all_users,function($u){return !empty(get_user_meta($u->ID,'_is_disabled',true));}));
    $trusted_count = count(orf_get_trusted_domains());
    ?>
    <div class="wrap">
        <h1>👑 OpenSimulator Royal Flush
            <span style="font-size:13px;font-weight:400;color:#999;margin-left:6px;">v<?php echo ORF_VERSION; ?></span>
            <a href="<?php echo admin_url('users.php?page=orf-settings'); ?>" class="page-title-action">⚙️ Trusted Domains</a>
        </h1>
        <p style="color:#666;">
            Safely review and remove no-avatar accounts from your OpenSimulator grid.
            <?php echo $trusted_count; ?> trusted domains excluded from bot detection.
            <a href="<?php echo admin_url('users.php?page=orf-settings'); ?>">Manage →</a>
            &nbsp;|&nbsp;<a href="https://github.com/mteedev/opensim-royal-flush" target="_blank" rel="noopener">GitHub →</a>
            &nbsp;|&nbsp;<a href="https://nerdypappy.com/opensim-royal-flush" target="_blank" rel="noopener">nerdypappy.com →</a>
        </p>

        <div style="display:flex;gap:14px;margin:16px 0;flex-wrap:wrap;">
            <?php foreach (array(
                array($total,'#1a3a5c','Total No-Avatar'),
                array($queued,'#b91c1c','Delete Queue (60+ days)'),
                array($disabled,'#92400e','Already Disabled'),
                array(count($bot_domains),'#b45309','Suspect Domains'),
                array($trusted_count,'#065f46','Trusted Domains'),
            ) as $s) : ?>
            <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:12px 18px;text-align:center;min-width:105px;">
                <div style="font-size:26px;font-weight:700;color:<?php echo $s[1]; ?>"><?php echo $s[0]; ?></div>
                <div style="font-size:11px;color:#666;"><?php echo $s[2]; ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <?php if (!empty($bot_domains)) : ?>
        <div style="background:#fff8f0;border:1px solid #f59e0b;border-radius:6px;padding:12px 16px;margin-bottom:12px;">
            <strong>⚠️ Suspected Bot Farm Domains</strong> (multiple accounts, not a trusted provider):&nbsp;
            <?php foreach ($bot_domains as $d=>$c) : ?>
            <span style="display:inline-block;background:#fef3c7;border:1px solid #f59e0b;border-radius:4px;padding:2px 8px;margin:2px;font-size:12px;">
                <?php echo esc_html($d); ?> (<?php echo $c; ?>)
            </span>
            <?php endforeach; ?>
            <a href="<?php echo admin_url('users.php?page=orf-settings'); ?>" style="margin-left:10px;font-size:12px;">Add to trusted domains →</a>
        </div>
        <?php else : ?>
        <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:6px;padding:10px 16px;margin-bottom:12px;font-size:13px;color:#065f46;">
            ✅ No suspected bot farm domains detected.
        </div>
        <?php endif; ?>

        <form method="post" style="display:inline-block;margin-bottom:14px;">
            <?php wp_nonce_field('orf_manual_scan','orf_scan_nonce'); ?>
            <input type="hidden" name="orf_scan" value="1">
            <button type="submit" class="button">▶ Run Scan Now</button>
        </form>
        <span style="color:#999;font-size:12px;margin-left:8px;">Normally runs automatically once daily via WP-Cron.</span>

        <form method="post" id="orf-form">
            <?php wp_nonce_field('orf_delete','orf_nonce'); ?>
            <div style="margin:10px 0;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                <button type="button" class="button" onclick="orfSelectAll()">☑ Select All</button>
                <button type="button" class="button" onclick="orfSelectQueued()">🗓 Select Queued</button>
                <button type="button" class="button" onclick="orfSelectDisabled()">🚫 Select Disabled</button>
                <button type="button" class="button" onclick="orfSelectNone()">☐ Deselect All</button>
                <span id="orf-sel-count" style="color:#b91c1c;font-weight:600;font-size:13px;">0 selected</span>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead><tr>
                    <td style="width:28px;"><input type="checkbox" onchange="orfToggleAll(this)"></td>
                    <th>Username</th><th>Email</th><th>Registered</th>
                    <th>Days Old</th><th>Last Seen</th><th>Status</th><th>Emails Sent</th><th>Queue</th>
                </tr></thead>
                <tbody>
                <?php foreach ($all_users as $user) :
                    $days   = orf_days($user);
                    $is_dis = !empty(get_user_meta($user->ID,'_is_disabled',true));
                    $is_q   = !empty(get_user_meta($user->ID,ORF_META_QUEUED,true));
                    $d30    = get_user_meta($user->ID,ORF_META_D30,true);
                    $d59    = get_user_meta($user->ID,ORF_META_D59,true);
                    $ls     = get_user_meta($user->ID,'wc_last_active',true);
                    $ls_str = $ls ? date('M j, Y',$ls) : '—';
                    $domain = orf_domain($user->user_email);
                    $is_bot = isset($bot_domains[$domain]);
                    $is_tr  = orf_is_trusted($domain);
                    $row_bg = $is_dis?'#fff1f1':($is_q?'#fff8f0':($days>=30?'#fffbeb':''));
                    $d_col  = $days>=60?'#b91c1c':($days>=30?'#92400e':'inherit');
                    $d_fw   = $days>=60?'700':'400';
                ?>
                <tr style="background:<?php echo $row_bg; ?>" data-disabled="<?php echo $is_dis?'1':'0'; ?>" data-queued="<?php echo $is_q?'1':'0'; ?>">
                    <td><input type="checkbox" name="orf_users[]" value="<?php echo $user->ID; ?>" class="orf-cb"></td>
                    <td>
                        <a href="<?php echo admin_url('user-edit.php?user_id='.$user->ID); ?>" target="_blank"><?php echo esc_html($user->user_login); ?></a>
                        <?php if ($is_bot) echo ' <span style="color:#b45309;font-size:11px;">⚠️ bot domain</span>'; ?>
                    </td>
                    <td style="font-size:12px;">
                        <?php echo esc_html($user->user_email); ?>
                        <?php if ($is_tr) echo ' <span style="color:#065f46;font-size:10px;" title="Trusted domain">✓</span>'; ?>
                    </td>
                    <td style="font-size:12px;"><?php echo date('M j, Y',strtotime($user->user_registered)); ?></td>
                    <td style="font-size:12px;font-weight:<?php echo $d_fw; ?>;color:<?php echo $d_col; ?>"><?php echo $days; ?> days</td>
                    <td style="font-size:12px;"><?php echo $ls_str; ?></td>
                    <td style="font-size:12px;"><?php echo $is_dis?'<span style="color:#b91c1c;font-weight:600;">🚫 Disabled</span>':'<span style="color:#065f46;">✓ Active</span>'; ?></td>
                    <td style="font-size:11px;">
                        <?php echo $d30?'<span style="color:#065f46;" title="Sent: '.esc_attr($d30).'">✓ D30</span> ':'<span style="color:#ccc;">○ D30</span> '; ?>
                        <?php echo $d59?'<span style="color:#b45309;" title="Sent: '.esc_attr($d59).'">✓ D59</span>':'<span style="color:#ccc;">○ D59</span>'; ?>
                    </td>
                    <td style="font-size:12px;">
                        <?php if ($is_q) echo '<span style="color:#b91c1c;font-weight:600;">🗓 Queued</span>';
                        elseif ($days>=30) echo '<span style="color:#92400e;">⏳ Pending</span>';
                        else echo '<span style="color:#aaa;">— Watching</span>'; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <div style="margin-top:16px;padding:16px;background:#fff1f1;border:1px solid #fca5a5;border-radius:6px;">
                <strong style="color:#b91c1c;">⚠️ Danger Zone</strong> —
                Selected accounts will be <strong>permanently deleted</strong> from WordPress. This cannot be undone.<br><br>
                <button type="submit" name="orf_delete" value="1" class="button button-primary"
                    style="background:#b91c1c;border-color:#991b1b;"
                    onclick="return orfConfirmDelete()">👑 Royal Flush Selected Accounts</button>
                <span id="orf-flush-count" style="margin-left:12px;color:#666;font-size:13px;">0 accounts selected</span>
            </div>
        </form>
    </div>
    <script>
    function orfToggleAll(cb){ document.querySelectorAll('.orf-cb').forEach(function(e){e.checked=cb.checked;}); orfCount(); }
    function orfSelectAll()     { document.querySelectorAll('.orf-cb').forEach(function(e){e.checked=true;}); orfCount(); }
    function orfSelectNone()    { document.querySelectorAll('.orf-cb').forEach(function(e){e.checked=false;}); orfCount(); }
    function orfSelectQueued()  { document.querySelectorAll('tr[data-queued="1"] .orf-cb').forEach(function(e){e.checked=true;}); orfCount(); }
    function orfSelectDisabled(){ document.querySelectorAll('tr[data-disabled="1"] .orf-cb').forEach(function(e){e.checked=true;}); orfCount(); }
    function orfCount() {
        var n = document.querySelectorAll('.orf-cb:checked').length;
        document.getElementById('orf-sel-count').textContent   = n+' selected';
        document.getElementById('orf-flush-count').textContent = n+' account(s) selected';
    }
    function orfConfirmDelete() {
        var n = document.querySelectorAll('.orf-cb:checked').length;
        if (!n){ alert('No accounts selected!'); return false; }
        return confirm('👑 Royal Flush: Permanently delete '+n+' account(s)?\n\nThis CANNOT be undone.\n\nAre you sure?');
    }
    document.querySelectorAll('.orf-cb').forEach(function(e){ e.addEventListener('change',orfCount); });
    </script>
    <?php
}
